package Polmanastra;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Film_Favoritku extends JFrame{
    private JPanel FilmFavoritku;
    private JRadioButton radioFilm3;
    private JRadioButton radioFilm2;
    private JRadioButton radioFilm1;
    private JLabel labelTampil;
    private JLabel labelFilm;
    private JLabel labelJudul;

    public Film_Favoritku() {
        radioFilm1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(radioFilm1.isSelected())
                {
                    labelTampil.setText("Iron Man 3");
                    FrameRadioButton();
                }
            }
        });
        radioFilm2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(radioFilm2.isSelected())
                {
                    labelTampil.setText("Spiderman 4");
                    FrameRadioButton();
                }
            }
        });
        radioFilm3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(radioFilm3.isSelected())
                {
                    labelTampil.setText("Transformer 3");
                    FrameRadioButton();
                }
            }
        });
    }

    public void FrameRadioButton(){
        ButtonGroup grup = new ButtonGroup();
        grup.add(radioFilm1);
        grup.add(radioFilm2);
        grup.add(radioFilm3);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Film Favoritku");
        frame.setContentPane(new Film_Favoritku().FilmFavoritku);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(450,300);
        frame.setVisible(true);
    }

}
