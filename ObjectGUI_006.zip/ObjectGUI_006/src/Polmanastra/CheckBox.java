package Polmanastra;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckBox extends JFrame implements ActionListener {
    private JPanel FieldCheckBox;
    private JCheckBox cbFilm1;
    private JCheckBox cbFilm2;
    private JCheckBox cbFilm3;
    private JCheckBox cbFilm4;
    private JTextArea textArea;
    private JLabel labelJudul;
    String film = "";

    public void FrameComboBox(){
        ButtonGroup grup = new ButtonGroup();
        grup.add(cbFilm1);
        grup.add(cbFilm2);
        grup.add(cbFilm3);
        grup.add(cbFilm4);
    }

    public static void main(String[] args) {
        JFrame frame = new CheckBox();
        frame.setContentPane(new CheckBox().FieldCheckBox);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(450,450);
        frame.setVisible(true);
    }

    public CheckBox(){
        cbFilm1.addActionListener(this);
        cbFilm2.addActionListener(this);
        cbFilm3.addActionListener(this);
        cbFilm4.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        film = "";
        if(cbFilm1.isSelected()){
            film += cbFilm1.getText() + "\n";
        }
        if(cbFilm2.isSelected()){
            film += cbFilm2.getText() + "\n";
        }
        if(cbFilm3.isSelected()){
            film += cbFilm3.getText() + "\n";
        }
        if(cbFilm4.isSelected()){
            film += cbFilm4.getText() + "\n";
        }
        textArea.setText(film);
    }

}
