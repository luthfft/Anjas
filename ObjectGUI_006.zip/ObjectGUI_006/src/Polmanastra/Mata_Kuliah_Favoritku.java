package Polmanastra;

import javax.swing.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class Mata_Kuliah_Favoritku extends JFrame{
    private JPanel MataKuliah;
    private JLabel labelKuliah;
    private JComboBox comboKuliah;
    private JTextField textKuliah;

    public Mata_Kuliah_Favoritku() {
        this.setSize(450,450);
        comboKuliah.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                textKuliah.setText((String) comboKuliah.getSelectedItem());
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Mata Kuliah");
        frame.setContentPane(new Mata_Kuliah_Favoritku().MataKuliah);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(450,300);
        frame.setVisible(true);
    }
}
